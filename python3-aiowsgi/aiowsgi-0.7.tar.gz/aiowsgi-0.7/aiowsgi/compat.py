# -*- coding: utf-8 -*-
try:
    import trollius as asyncio
except ImportError:
    import asyncio  # NOQA
