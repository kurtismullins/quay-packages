0.7 (2018-11-02)
================

- remove deprecated asyncio.async calls


0.6 (2016-06-30)
================

- Small changes to work with latest waitress release (force encoding data to utf8)


0.5 (2015-03-19)
================

- Use executor iif application is not a coroutine


0.4 (2015-03-13)
================

- Added thread.WSGIServer


0.3 (2014-06-19)
================

- Compat with latest trollius


0.2 (2014-05-10)
================

- Use waitress's tasks to parse request and send response
