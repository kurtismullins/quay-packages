================================================
aiowsgi - minimalist wsgi server using asyncio
================================================

.. image:: https://travis-ci.org/gawel/aiowsgi.png?branch=master
  :target: https://travis-ci.org/gawel/aiowsgi
.. image:: https://coveralls.io/repos/gawel/aiowsgi/badge.png?branch=master
  :target: https://coveralls.io/r/gawel/aiowsgi?branch=master
.. image:: https://img.shields.io/pypi/v/aiowsgi.svg
   :target: https://crate.io/packages/aiowsgi/
.. image:: https://img.shields.io/pypi/dm/aiowsgi.svg
   :target: https://crate.io/packages/aiowsgi/

Require python 2.7, 3.3+

Source: https://github.com/gawel/aiowsgi/

Docs: https://aiowsgi.readthedocs.org/

You like it ? => https://www.gittip.com/gawel/
